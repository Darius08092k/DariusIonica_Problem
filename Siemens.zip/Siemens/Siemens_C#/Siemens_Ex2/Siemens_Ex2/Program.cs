﻿using System;
using System.Collections;
using System.Text.RegularExpressions;

namespace Siemens_Ex2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please input the number of strings: ");
            int num = Int32.Parse(Console.ReadLine());
            String[] text = new String[num + 1];
            Console.WriteLine("Please input the strings: ");
            int i = 0;
            while (i <= num)
            {
                text[i] = Console.ReadLine();
                i++;
            }
            sortArray(text);
        }

        public static ArrayList findNumbers(String input)
        {
            ArrayList numbers = new ArrayList();
            Regex rx = new Regex("\\d+");
            MatchCollection match = rx.Matches(input);
            int i = 0;
            foreach (Match m in match)
            {
                GroupCollection groups = m.Groups;
                numbers.Add(Int32.Parse(m.Value));
            }
          
            return numbers;
        }
        static void sortArray(String[] inputString)
        {
            ArrayList sorted = new ArrayList();
            foreach (String el in inputString)
            {
                ArrayList temp = findNumbers(el);
                foreach (int number in temp)
                {
                    if (!sorted.Contains(number))
                        sorted.Add(number);
                }
            }
            sorted.Sort();
            printArrayList(sorted);
        }

        static void printArrayList(ArrayList arrayList)
        {
            foreach (Object o in arrayList)
                Console.Write(o+" ");
            
        }
    }
}
