package Ex2;
import java.util.ArrayList;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

public class MAin {
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        System.out.println("Please input the number of strings: ");
        int num= scan.nextInt();
        String[] text = new String[num+1];
        System.out.println("Please input the strings: ");
        int i =0;
        while(i<=num){
            text[i] = scan.nextLine();
            i++;
        }
        sortArray(text);
    }

    public static ArrayList<Integer> findNumbers(String input){
        ArrayList<Integer> numbers = new ArrayList<Integer>();
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher(input);
        int i = 0;
        while(m.find()){
            numbers.add(Integer.parseInt(m.group()));

        }
        return numbers;
    }

    static void sortArray(String[] inputString)
    {
        ArrayList<Integer> sorted = new ArrayList<>();
        for (String el : inputString)
        {
            ArrayList<Integer> temp = findNumbers(el);
            for (int number : temp) {
                if(!sorted.contains(number))
                    sorted.add(number);
            }
        }
        Collections.sort(sorted);
        System.out.println(sorted);
        }
}

